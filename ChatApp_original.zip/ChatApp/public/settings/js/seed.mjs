let seed = {
  name: "Michael Jordan",
  bio:
    "\
This is my test bio. \
This is my test bio. \
This is my test bio. \
This is my test bio. \
This is my test bio. \
This is my test bio.",
  emails: ["leo@gmail.com", "test@user.com"],
  numbers: ["09087654321", "08012345678"],
  privacy: {
    group: "anyone",
    profile: "everyone"
  }
};

export default seed;
